#include"libft.h"
int main(void)
{
    printf("%d\n",ft_isalpha('&'));
    printf("%d\n",ft_isalpha(64));//@//
    printf("%d\n",ft_isalpha(65));//A//
    printf("%d\n",ft_isalpha(96));//'//
    printf("%d\n",ft_isalpha(97));//a//
    printf("%d\n",ft_isalpha(123));//{//
    return(0);
}