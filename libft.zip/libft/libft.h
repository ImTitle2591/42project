#ifndef LIBFT_H
# define LIBFT_H
# include<stdio.h>

int ft_isalpha(int c);
#endif