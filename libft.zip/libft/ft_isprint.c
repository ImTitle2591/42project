
int ft_isprint(int c)
{
    if ((c >= 0 && c <= 32) || (c >= 127))
        return(1);
    return(0);
}