#include <stdio.h>
int ft_toupper(unsigned char c)
{
    if (c >= 97 && c <= 122)
        return(c+32);
    return(0);
}

int main(void)
{
    printf("%d\n",ft_toupper('&'));
    printf("%d\n",ft_toupper(64));//@//
    printf("%d\n",ft_toupper(65));//A//
    printf("%d\n",ft_toupper(96));//'//
    printf("%d\n",ft_toupper(97));//a//
    printf("%d\n",ft_toupper(123));//{//
    printf("%d\n",ft_toupper(12));//\f//
    return(0);
}